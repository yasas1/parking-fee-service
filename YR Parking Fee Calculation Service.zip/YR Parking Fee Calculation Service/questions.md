01. How can we pass dates to the fee calculation API? 
    1. Year and the month can be passed 
    2. start date and end date can be passed. 
    So the functionality can be used more than one month and the requirement can be achieved from the client side.
    (Used)