package com.parking.fee.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingFeeServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
