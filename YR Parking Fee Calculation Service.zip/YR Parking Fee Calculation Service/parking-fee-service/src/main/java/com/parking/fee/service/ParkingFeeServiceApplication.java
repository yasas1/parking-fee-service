package com.parking.fee.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingFeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingFeeServiceApplication.class, args);
	}

}
