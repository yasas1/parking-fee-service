01. Monthly charge rule and parking fee exempt vehicles can be stored in the db for different cities

02. Parking fee for the weekends also can be configured according to different cities

03. City, weekday fee rules and public holidays data were cached in Maps since those are not changing frequently.
Also those caches can be improved according to update/delete functionalities and APIs can be introduced to clear.

04. Unit and Integration test can be added.